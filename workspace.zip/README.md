# Pump.fun momentum engine

A stateful Node.js/TypeScript backend that reproduces the behavior observed in the supplied target-wallet sample: it watches **new Pump.fun bonding-curve launches**, waits for genuine buy-side participation, sizes entries from roughly 0.05 to 1.2 SOL, and sells in multiple tranches over a short holding window. It does not pretend that the incomplete 80-transaction sample proves a universal strategy; every inferred threshold is configurable.

The process starts in paper mode. Live mode signs locally and submits the same serialized transaction to multiple configured RPC providers. The wallet secret is never sent to PumpPortal.

## Strategy

For each Pump.fun launch, the engine subscribes to that mint's trades for an 8-second observation period and requires:

- at least 4 distinct buyers;
- at least 65% buy transactions and 0.5 SOL net buy flow;
- a 20–140 SOL market cap;
- no active mint or freeze authority (checked on-chain);
- no oversized creator initial buy.

At most 64 candidates are tracked simultaneously, preventing an event burst from creating unbounded subscriptions.

Entry size increases with unique buyers, net inflow, and buy ratio. A position sells 35% of its original tokens at +25%, another 35% at +65%, and trails the remainder by 22%. A -18% stop or 180-second maximum hold exits all remaining tokens.

The market monitor consumes every subscribed trade and keeps a bounded 30-second window of reserve-derived price, high/low movement, buy/sell flow, and executable SOL depth. Pump bonding-curve depth excludes the default 30 virtual SOL because it is not withdrawable. Market cap divided by the fixed Pump supply is used only when reserve fields are unavailable. Entries require fresh reserve data and 1.5 SOL of known depth; positions exit if known depth falls below 0.75 SOL, drops 45% from its post-entry peak, or heavy sell flow accompanies a 10% drawdown. Unknown post-migration liquidity does not invent a value or suppress ordinary stop-losses.

Every sell is capped to 10% estimated constant-product price impact. If a stop or target is larger, it is completed across subsequent trade updates, which reproduces the observed wallet's multi-tranche exits without submitting an oversized thin-curve order. Take-profit fill progress plus peak price/liquidity watermarks are checkpointed to disk, so restart does not reset trailing risk.

Only the Pump.fun bonding curve is accepted for entry. If the token migrates while held, a `pump-amm` trade event updates the exit venue automatically. The local transaction builder's `pool` is never left on `auto`, preventing an unintended generic-router flow.

## Run

Node 20 or newer is required.

```sh
cp .env.example .env
npm install
npm test
npm run dev
```

`PUMPPORTAL_API_KEY` is required because token-trade subscriptions are metered. Set one or more dedicated RPCs in `RPC_HTTP_URLS`; live mode requires at least two and rejects the public Solana mainnet endpoint. Verify the provider URLs and limits with your vendors.

To enable real orders, fund a dedicated hot wallet, set its base58 or JSON-array secret in `WALLET_PRIVATE_KEY`, then set both:

```dotenv
DRY_RUN=false
LIVE_TRADING_ACK=I_UNDERSTAND_REAL_FUNDS_ARE_AT_RISK
```

Create an empty file named `HALT` to stop new entries. Existing positions continue to follow their exit rules. Remove it to resume entries. State is atomically persisted to `state/engine.json`; do not edit it while the process is running.

## RPC reliability

The RPC pool enforces a per-endpoint request rate, rotates providers on errors, honors `Retry-After` for HTTP 429, uses exponential circuit-breaker delays, and broadcasts an identical signed transaction to every configured endpoint. Because identical Solana transactions have the same signature, this improves landing without creating duplicate orders. If confirmation is uncertain, the executor reconciles token balances instead of blindly resubmitting a new trade.

## Important operational notes

- Start in paper mode and inspect several sessions before risking funds.
- PumpPortal builds venue-specific transactions and charges its own fee in addition to Pump.fun and network fees.
- The observed account was very active (about 11 transactions/minute in the available slice); the daily-spend and concurrent-position limits intentionally cap exposure rather than copying that risk blindly.
- A clean shutdown preserves open positions; restarting resumes their trade subscriptions and time-based exits.
- Logs redact common key fields. Keep `.env`, state, and the hot-wallet secret outside backups and source control.
