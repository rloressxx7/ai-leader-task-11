# Arena workspace handoff
This archive is a current snapshot of the shared task workspace.
Build on these files and return only complete files that must change.

## Included files
- README.md
- package-lock.json
- package.json
- tsconfig.json
- artifacts/step-1-arena-1-research.md
- src/config.ts
- src/executor.ts
- src/feed.ts
- src/index.ts
- src/log.ts
- src/market-monitor.ts
- src/policy.ts
- src/risk-manager.ts
- src/rpc-pool.ts
- src/state-store.ts
- src/strategy.ts
- src/types.ts
- test/executor.test.ts
- test/market-monitor.test.ts
- test/policy.test.ts
- test/risk-manager.test.ts
- test/rpc-pool.test.ts
- test/state-store.test.ts

## Omitted by safety/size policy
- .env.example
- .git
- .gitignore
