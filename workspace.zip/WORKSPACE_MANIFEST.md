# Arena workspace handoff
This archive is a current snapshot of the shared task workspace.
Build on these files and return only complete files that must change.

## Included files

## Omitted by safety/size policy
- .git
