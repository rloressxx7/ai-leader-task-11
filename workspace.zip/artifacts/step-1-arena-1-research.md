# Research handoff — arena#1

Task: Analyze the transaction history of wallet 2CQgjcdNEo7WtbQLpJTAVcC3Ga61pNvRDTgP5grzctFG on Solscan or via a reliable RPC to identify patterns: timing of buys/sells, token selection criteria (newly minted vs established), slippage settings, and interaction with specific DEXs (Raydium, Jupiter, etc.).

I need to analyze the target Solana wallet's transaction history and produce code changes.
I'll inspect the workspace snapshot and the GitHub repo first so we can analyze this wallet against the existing project instead of starting over.
used
Bash
81ms
Searched for "2CQgjcdNEo7WtbQLpJTAVcC3Ga61pNvRDTgP5grzctFG solscan"
The local workspace is empty, so I’ll pull the GitHub snapshot next and inspect the wallet on Solscan.
Searched the web
I'll download the workspace zip and pull the wallet's Solscan page so we can inspect real on-chain activity.
used
Bash
527ms
Fetched https://solscan.io/account/2CQgjcdNEo7WtbQLpJTAVcC3Ga61pNvRDTgP5grzctFG
The workspace archive contains only a manifest file. No source code is present.
This appears to be a trading bot project. The goal is to replicate the on-chain behavior of a specific wallet. I will examine the workspace manifest and Solscan transaction history to understand the target venue and flow.
Workspace is almost empty. Next I’ll read the manifest and pull more of this wallet’s Solscan history.
used
Bash
163ms
Searched the web
The task is to analyze a specific Solana wallet and replicate its trading behavior.
The workspace is empty. I am gathering on-chain data for wallet 2CQgjcdNEo7WtbQLpJTAVcC3Ga61pNvRDTgP5grzctFG. It holds 182 SOL and was funded by account 9BhkaAybG824w5Hk2A1Np22ZwYN74f6kisJtLEK9C6Ns four months ago. The funding transaction involved 171,494 accounts. This indicates a high-volume sniper or copy-trader strategy.
Recent transactions reveal a clear pump-and-dump pattern. The wallet sold three small amounts of token 9jijNKELHGCK6H1GtqM7wtC5BqbwwizpkmzQCKyE9qij one minute apart, then bought it for 0.05184 SOL. It also sold GLpzVozN5g9vCQBsXdhpGojaVRXHn6FKTRF6tsqYpump multiple times over the past three minutes, totaling 1.73 SOL in sales, and bought that same pump token for 1.23 SOL.
The wallet also sold token 4sG1CKVGXqGPPKKLxJCT53ZaTbfurx2VPQ8E5TCtohS8 for 0.06769 SOL nine minutes ago. The involved programs are Pump.fun, its fee program, G4, and a third unidentified program. This confirms the wallet is a Pump.fun sniper that buys newly minted tokens and sells them in multiple tranches within minutes.
The HOOD token may serve as an intermediate hop in two-hop swaps. I will fetch additional Solscan data, individual transactions, and analytics from Birdeye or GMGN. Public RPC endpoints will also be used to gather more on-chain details.
The user wants a working analysis tool and a trading engine that replicates this wallet's behavior. I will produce the full final content of every file in the required fenced-block format.
I will build the project directly in the workspace and then return the final file contents in the requested fenced-block format.
I’ll pull more of this wallet’s trades, inspect a few transactions, and check copy-trading analytics so the replica matches real on-chain flow.
Searched the web
I’ll inspect individual transactions and public APIs next so we can pin down DEX, size, and timing.
Searched the web
used
Bash
331ms
The public RPC call succeeded this time.
Fetching more transaction data to analyze program usage, trade amounts, timing, slippage, and token types. The wallet trades exclusively on Pump.fun. A recent buy of Loom (GLpz...pump) for 1.215 SOL (~$151) was identified. Two router programs were also spotted.
Buy transactions cost 2 SOL plus 0.0036 tip, 0.0057 buyback, and 0.0057 protocol fee. Sells are executed in multiple tranches within minutes. Some trades quote tokens in HOODx instead of SOL. The wallet uses Token 2022 and creates temporary WSOL accounts via createAccountWithSeed.
The wallet has funded 171,494 accounts. This suggests a market maker or volume bot. Buy sizes range from 0.05 SOL to roughly 1.2 SOL. A comprehensive analysis script is being prepared to fetch signatures and parse transactions via RPC and Solscan.
RPC is responding. I’ll pull signatures and parse recent swaps so we can measure size, venue, and timing.
used
Bash
390ms
Thinking...
The on-chain analysis revealed only 80 transactions in 433 seconds, or roughly 11 per minute.
