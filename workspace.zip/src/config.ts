import "dotenv/config";
import { z } from "zod";

const bool = z.enum(["true", "false"]).default("true").transform((v) => v === "true");
const number = (fallback: number) => z.coerce.number().finite().default(fallback);
const positive = (fallback: number) => number(fallback).pipe(z.number().positive());

const schema = z.object({
  RPC_HTTP_URLS: z.string().default(""),
  RPC_REQUESTS_PER_SECOND: positive(20),
  RPC_TIMEOUT_MS: positive(8_000),
  PUMPPORTAL_API_KEY: z.string().default(""),
  PUMPPORTAL_WS_URL: z.string().url().default("wss://pumpportal.fun/api/data"),
  PUMPPORTAL_TRADE_URL: z.string().url().default("https://pumpportal.fun/api/trade-local"),
  DRY_RUN: bool,
  LIVE_TRADING_ACK: z.string().default(""),
  WALLET_PRIVATE_KEY: z.string().default(""),
  BASE_BUY_SOL: positive(0.05),
  MAX_BUY_SOL: positive(1.2),
  MAX_OPEN_POSITIONS: z.coerce.number().int().positive().default(4),
  MAX_TRACKED_CANDIDATES: z.coerce.number().int().positive().default(64),
  MAX_DAILY_SPEND_SOL: positive(5),
  MIN_WALLET_RESERVE_SOL: number(0.1).pipe(z.number().nonnegative()),
  OBSERVATION_MS: positive(8_000),
  MIN_UNIQUE_BUYERS: z.coerce.number().int().positive().default(4),
  MIN_BUY_RATIO: number(0.65).pipe(z.number().min(0).lt(1)),
  MIN_NET_BUY_SOL: number(0.5).pipe(z.number().nonnegative()),
  MIN_MARKET_CAP_SOL: positive(20),
  MAX_MARKET_CAP_SOL: positive(140),
  STOP_LOSS_PCT: positive(18).pipe(z.number().lt(100)),
  TAKE_PROFIT_1_PCT: positive(25),
  TAKE_PROFIT_2_PCT: positive(65),
  TRAILING_STOP_PCT: positive(22).pipe(z.number().lt(100)),
  MAX_HOLD_MS: positive(180_000),
  MARKET_WINDOW_MS: positive(30_000),
  MARKET_STALE_MS: positive(15_000),
  PUMP_VIRTUAL_SOL_OFFSET: number(30).pipe(z.number().nonnegative()),
  MIN_ENTRY_LIQUIDITY_SOL: number(1.5).pipe(z.number().nonnegative()),
  MIN_EXIT_LIQUIDITY_SOL: number(0.75).pipe(z.number().nonnegative()),
  LIQUIDITY_DRAWDOWN_EXIT_PCT: positive(45).pipe(z.number().lt(100)),
  MAX_EXIT_PRICE_IMPACT_PCT: positive(10).pipe(z.number().lt(100)),
  SELL_PRESSURE_EXIT_RATIO: positive(0.8).pipe(z.number().max(1)),
  SELL_PRESSURE_MIN_VOLUME_SOL: number(0.75).pipe(z.number().nonnegative()),
  SELL_PRESSURE_PRICE_DROP_PCT: positive(10).pipe(z.number().lt(100)),
  RISK_CHECKPOINT_MS: positive(5_000),
  SLIPPAGE_PCT: positive(12).pipe(z.number().max(100)),
  PRIORITY_FEE_SOL: number(0.0005).pipe(z.number().nonnegative()),
  MAX_CREATOR_INITIAL_BUY_PCT: number(5).pipe(z.number().min(0).max(100)),
  STATE_FILE: z.string().default("state/engine.json"),
  HALT_FILE: z.string().default("HALT"),
  LOG_LEVEL: z.string().default("info")
});

const env = schema.parse(process.env);
const rpcUrls = env.RPC_HTTP_URLS.split(",").map((x) => x.trim()).filter(Boolean);

if (env.MAX_BUY_SOL < env.BASE_BUY_SOL) throw new Error("MAX_BUY_SOL must be >= BASE_BUY_SOL");
if (env.MAX_MARKET_CAP_SOL <= env.MIN_MARKET_CAP_SOL) throw new Error("MAX_MARKET_CAP_SOL must exceed MIN_MARKET_CAP_SOL");
if (env.MIN_EXIT_LIQUIDITY_SOL > env.MIN_ENTRY_LIQUIDITY_SOL) throw new Error("MIN_EXIT_LIQUIDITY_SOL must be <= MIN_ENTRY_LIQUIDITY_SOL");
if (env.MAX_EXIT_PRICE_IMPACT_PCT > env.SLIPPAGE_PCT) throw new Error("MAX_EXIT_PRICE_IMPACT_PCT must be <= SLIPPAGE_PCT");
if (!env.DRY_RUN) {
  if (env.LIVE_TRADING_ACK !== "I_UNDERSTAND_REAL_FUNDS_ARE_AT_RISK") throw new Error("Live trading acknowledgement is missing");
  if (!env.WALLET_PRIVATE_KEY) throw new Error("WALLET_PRIVATE_KEY is required for live trading");
  if (rpcUrls.length < 2) throw new Error("Live mode requires at least two dedicated RPC_HTTP_URLS");
  if (rpcUrls.some((u) => /api\.mainnet(?:-beta)?\.solana\.com/i.test(u))) throw new Error("Public Solana RPC is rate-limited and forbidden in live mode");
}
export const config = { ...env, rpcUrls };
export type Config = typeof config;
