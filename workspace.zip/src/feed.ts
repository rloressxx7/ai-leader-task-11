import { EventEmitter } from "node:events";
import WebSocket from "ws";
import { setTimeout as delay } from "node:timers/promises";
import { log } from "./log.js";
import type { LaunchEvent, TradeEvent } from "./types.js";

type FeedEvents = { launch: [LaunchEvent]; trade: [TradeEvent]; error: [Error] };

export class PumpPortalFeed extends EventEmitter<FeedEvents> {
  private ws?: WebSocket;
  private stopped = false;
  private reconnectAttempt = 0;
  private readonly watched = new Set<string>();
  private heartbeat?: NodeJS.Timeout;

  constructor(private readonly baseUrl: string, private readonly apiKey: string) { super(); }

  start(): void { this.stopped = false; this.connect(); }

  stop(): void {
    this.stopped = true;
    if (this.heartbeat) clearInterval(this.heartbeat);
    this.ws?.removeAllListeners();
    this.ws?.close();
  }

  watch(mint: string): void {
    if (this.watched.has(mint)) return;
    this.watched.add(mint);
    this.send({ method: "subscribeTokenTrade", keys: [mint] });
  }

  unwatch(mint: string): void {
    if (!this.watched.delete(mint)) return;
    this.send({ method: "unsubscribeTokenTrade", keys: [mint] });
  }

  private connect(): void {
    if (this.stopped) return;
    const url = new URL(this.baseUrl);
    url.searchParams.set("api-key", this.apiKey);
    const ws = new WebSocket(url);
    this.ws = ws;
    ws.on("open", () => {
      this.reconnectAttempt = 0;
      log.info("PumpPortal stream connected");
      this.send({ method: "subscribeNewToken" });
      if (this.watched.size) this.send({ method: "subscribeTokenTrade", keys: [...this.watched] });
      if (this.heartbeat) clearInterval(this.heartbeat);
      this.heartbeat = setInterval(() => { if (ws.readyState === WebSocket.OPEN) ws.ping(); }, 20_000);
    });
    ws.on("message", (raw) => this.handle(raw.toString()));
    ws.on("error", (error) => this.emit("error", error));
    ws.on("close", () => {
      if (this.heartbeat) clearInterval(this.heartbeat);
      if (!this.stopped) void this.reconnect();
    });
  }

  private async reconnect(): Promise<void> {
    const wait = Math.min(30_000, 500 * 2 ** this.reconnectAttempt++) + Math.floor(Math.random() * 500);
    log.warn({ wait }, "PumpPortal stream disconnected; reconnecting");
    await delay(wait);
    this.connect();
  }

  private handle(raw: string): void {
    try {
      const value = JSON.parse(raw) as Record<string, unknown>;
      if (typeof value.mint !== "string" || typeof value.signature !== "string") return;
      const common = {
        signature: value.signature,
        mint: value.mint,
        trader: String(value.traderPublicKey ?? ""),
        solAmount: finite(value.solAmount),
        tokenAmount: finite(value.tokenAmount ?? value.initialBuy),
        marketCapSol: finite(value.marketCapSol),
        pool: normalizePool(value.pool),
        timestamp: Date.now(),
        ...optionalNumber("virtualSolReserves", value.vSolInBondingCurve ?? value.virtualSolReserves),
        ...optionalNumber("virtualTokenReserves", value.vTokensInBondingCurve ?? value.virtualTokenReserves),
        ...optionalNumber("realSolReserves", value.realSolReserves),
        ...optionalNumber("realTokenReserves", value.realTokenReserves)
      };
      if (value.txType === "create" || typeof value.name === "string") {
        this.emit("launch", { kind: "launch", ...common, name: String(value.name ?? ""), symbol: String(value.symbol ?? ""), ...(typeof value.uri === "string" ? { uri: value.uri } : {}) });
      } else if (value.txType === "buy" || value.txType === "sell") {
        this.emit("trade", { kind: "trade", ...common, side: value.txType });
      }
    } catch (error) {
      log.debug({ err: String(error), raw: raw.slice(0, 300) }, "Ignored malformed feed message");
    }
  }

  private send(payload: unknown): void {
    if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify(payload));
  }
}

function finite(value: unknown): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function optionalNumber<K extends string>(key: K, value: unknown): { [P in K]?: number } {
  if (value === null || value === "") return {};
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed >= 0 ? { [key]: parsed } as { [P in K]?: number } : {};
}

function normalizePool(value: unknown): string {
  const pool = String(value ?? "pump").toLowerCase();
  return pool === "pump-amm" || pool === "raydium" ? pool : "pump";
}
