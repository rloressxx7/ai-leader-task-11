import { config } from "./config.js";
import { PortalExecutor, PaperExecutor, loadKeypair } from "./executor.js";
import { PumpPortalFeed } from "./feed.js";
import { log } from "./log.js";
import { RpcPool } from "./rpc-pool.js";
import { StateStore } from "./state-store.js";
import { MomentumEngine } from "./strategy.js";

async function main(): Promise<void> {
  if (!config.PUMPPORTAL_API_KEY) throw new Error("PUMPPORTAL_API_KEY is required for the metered token-trade stream");
  const rpc = config.rpcUrls.length
    ? new RpcPool(config.rpcUrls, config.RPC_REQUESTS_PER_SECOND, config.RPC_TIMEOUT_MS)
    : undefined;
  const feed = new PumpPortalFeed(config.PUMPPORTAL_WS_URL, config.PUMPPORTAL_API_KEY);
  let wallet: string | undefined;
  let executor;
  if (config.DRY_RUN) {
    executor = new PaperExecutor();
    if (!rpc) log.warn("Paper mode has no RPC configured; mint-authority checks and wallet reserve checks are disabled");
  } else {
    if (!rpc) throw new Error("RPC_HTTP_URLS is required for live mode");
    const signer = loadKeypair(config.WALLET_PRIVATE_KEY);
    wallet = signer.publicKey.toBase58();
    executor = new PortalExecutor(config, rpc, signer);
  }
  const engine = new MomentumEngine(config, feed, executor, new StateStore(config.STATE_FILE), rpc, wallet);
  await engine.start();

  let stopping = false;
  const shutdown = async (signal: string) => {
    if (stopping) return;
    stopping = true;
    log.info({ signal }, "Stopping; open positions remain persisted and managed on next start");
    await engine.stop();
    process.exitCode = 0;
  };
  process.on("SIGINT", () => { void shutdown("SIGINT"); });
  process.on("SIGTERM", () => { void shutdown("SIGTERM"); });
  process.on("uncaughtException", (error) => { log.fatal({ err: error }, "Uncaught exception"); void shutdown("uncaughtException"); });
  process.on("unhandledRejection", (error) => { log.fatal({ err: error }, "Unhandled rejection"); void shutdown("unhandledRejection"); });
}

main().catch((error) => { log.fatal({ err: error }, "Startup failed"); process.exitCode = 1; });
