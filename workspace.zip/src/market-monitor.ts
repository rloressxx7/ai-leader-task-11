import type { Config } from "./config.js";
import type { LaunchEvent, MarketPriceSource, MarketSnapshot, PersistedPosition, TradeEvent } from "./types.js";

type MarketEvent = LaunchEvent | TradeEvent;

interface Sample {
  timestamp: number;
  priceSol: number;
  priceSource: MarketPriceSource;
  marketCapSol: number;
  buySol: number;
  sellSol: number;
  liquiditySol?: number;
  virtualTokenReserves?: number;
}

interface MarketRecord {
  samples: Sample[];
  signatures: Set<string>;
  peakLiquiditySol?: number;
}

/** Maintains bounded, per-mint rolling market state from the same low-latency feed used for execution. */
export class MarketMonitor {
  private readonly markets = new Map<string, MarketRecord>();

  constructor(private readonly config: Pick<Config, "MARKET_WINDOW_MS" | "MARKET_STALE_MS" | "PUMP_VIRTUAL_SOL_OFFSET">) {}

  observe(event: MarketEvent): MarketSnapshot | undefined {
    const record = this.markets.get(event.mint) ?? { samples: [], signatures: new Set<string>() };
    this.markets.set(event.mint, record);
    if (record.signatures.has(event.signature)) return undefined;
    record.signatures.add(event.signature);
    if (record.signatures.size > 512) record.signatures.delete(record.signatures.values().next().value!);

    const previous = record.samples.at(-1);
    const reservePrice = positiveRatio(event.virtualSolReserves, event.virtualTokenReserves);
    const marketCapPrice = event.marketCapSol > 0 ? event.marketCapSol / 1_000_000_000 : undefined;
    const priceSol = reservePrice ?? marketCapPrice ?? previous?.priceSol;
    if (!priceSol || !Number.isFinite(priceSol)) return undefined;

    const liquiditySol = this.liquidity(event);
    if (liquiditySol !== undefined) record.peakLiquiditySol = Math.max(record.peakLiquiditySol ?? 0, liquiditySol);
    const isBuy = event.kind === "launch" || event.side === "buy";
    record.samples.push({
      timestamp: event.timestamp,
      priceSol,
      priceSource: reservePrice ? "bonding-curve" : marketCapPrice ? "market-cap" : previous!.priceSource,
      marketCapSol: event.marketCapSol || previous?.marketCapSol || 0,
      buySol: isBuy ? Math.max(0, event.solAmount) : 0,
      sellSol: isBuy ? 0 : Math.max(0, event.solAmount),
      ...(liquiditySol !== undefined ? { liquiditySol } : {}),
      ...(event.virtualTokenReserves !== undefined ? { virtualTokenReserves: event.virtualTokenReserves } : {})
    });
    this.trim(record, event.timestamp);
    return this.build(event.mint, record, event.timestamp);
  }

  /** Restores the last persisted risk watermark so a restart cannot reset a trailing stop. */
  seed(position: PersistedPosition): void {
    if (this.markets.has(position.mint)) return;
    const priceSol = position.lastPriceSol ?? position.entryPriceSol ?? position.entryMarketCapSol / 1_000_000_000;
    const timestamp = position.lastMarketUpdateAt ?? position.openedAt;
    const sample: Sample = {
      timestamp,
      priceSol,
      priceSource: "market-cap",
      marketCapSol: position.peakMarketCapSol,
      buySol: 0,
      sellSol: 0,
      ...(position.lastLiquiditySol !== undefined ? { liquiditySol: position.lastLiquiditySol } : {})
    };
    this.markets.set(position.mint, {
      samples: [sample],
      signatures: new Set(),
      ...(position.peakLiquiditySol !== undefined ? { peakLiquiditySol: position.peakLiquiditySol } : {})
    });
  }

  snapshot(mint: string, now = Date.now()): MarketSnapshot | undefined {
    const record = this.markets.get(mint);
    if (!record?.samples.length) return undefined;
    this.trim(record, now);
    return this.build(mint, record, now);
  }

  forget(mint: string): void { this.markets.delete(mint); }

  private liquidity(event: MarketEvent): number | undefined {
    if (event.realSolReserves !== undefined) return Math.max(0, event.realSolReserves);
    if (event.pool === "pump" && event.virtualSolReserves !== undefined) {
      // Pump's virtual reserve includes protocol-seeded virtual SOL which cannot be withdrawn.
      return Math.max(0, event.virtualSolReserves - this.config.PUMP_VIRTUAL_SOL_OFFSET);
    }
    return undefined;
  }

  private trim(record: MarketRecord, now: number): void {
    const cutoff = now - this.config.MARKET_WINDOW_MS;
    while (record.samples.length > 1 && record.samples[0]!.timestamp < cutoff) record.samples.shift();
  }

  private build(mint: string, record: MarketRecord, now: number): MarketSnapshot {
    const samples = record.samples;
    const latest = samples.at(-1)!;
    let high = latest.priceSol;
    let low = latest.priceSol;
    let buyVolumeSol = 0;
    let sellVolumeSol = 0;
    for (const sample of samples) {
      high = Math.max(high, sample.priceSol);
      low = Math.min(low, sample.priceSol);
      buyVolumeSol += sample.buySol;
      sellVolumeSol += sample.sellSol;
    }
    const totalVolume = buyVolumeSol + sellVolumeSol;
    const liquiditySol = latest.liquiditySol;
    const peakLiquiditySol = record.peakLiquiditySol;
    const liquidityDrawdownPct = liquiditySol !== undefined && peakLiquiditySol && peakLiquiditySol > 0
      ? Math.max(0, (1 - liquiditySol / peakLiquiditySol) * 100)
      : undefined;
    return {
      mint,
      timestamp: latest.timestamp,
      priceSol: latest.priceSol,
      priceSource: latest.priceSource,
      marketCapSol: latest.marketCapSol,
      windowHighPriceSol: high,
      windowLowPriceSol: low,
      windowChangePct: percentChange(samples[0]!.priceSol, latest.priceSol),
      windowDrawdownPct: high > 0 ? Math.max(0, (1 - latest.priceSol / high) * 100) : 0,
      buyVolumeSol,
      sellVolumeSol,
      sellPressureRatio: totalVolume > 0 ? sellVolumeSol / totalVolume : 0,
      tradeCount: samples.length,
      ...(liquiditySol !== undefined ? { liquiditySol } : {}),
      ...(peakLiquiditySol !== undefined ? { peakLiquiditySol } : {}),
      ...(liquidityDrawdownPct !== undefined ? { liquidityDrawdownPct } : {}),
      ...(latest.virtualTokenReserves !== undefined ? { virtualTokenReserves: latest.virtualTokenReserves } : {}),
      stale: now - latest.timestamp > this.config.MARKET_STALE_MS
    };
  }
}

export function estimatedSellImpactPct(snapshot: MarketSnapshot, rawAmount: bigint, decimals: number): number | undefined {
  if (!snapshot.virtualTokenReserves || snapshot.virtualTokenReserves <= 0 || rawAmount <= 0n) return undefined;
  const tokenAmount = Number(rawAmount) / 10 ** decimals;
  if (!Number.isFinite(tokenAmount)) return 100;
  return tokenAmount / (snapshot.virtualTokenReserves + tokenAmount) * 100;
}

export function capSellForImpact(snapshot: MarketSnapshot, rawAmount: bigint, decimals: number, maxImpactPct: number): bigint {
  if (!snapshot.virtualTokenReserves || snapshot.virtualTokenReserves <= 0 || rawAmount <= 0n) return rawAmount;
  const impact = maxImpactPct / 100;
  const maxTokens = snapshot.virtualTokenReserves * impact / (1 - impact);
  const maxRawNumber = Math.floor(maxTokens * 10 ** decimals);
  if (!Number.isFinite(maxRawNumber) || maxRawNumber <= 0) return rawAmount;
  return min(rawAmount, BigInt(maxRawNumber));
}

function positiveRatio(numerator: number | undefined, denominator: number | undefined): number | undefined {
  if (numerator === undefined || denominator === undefined || numerator <= 0 || denominator <= 0) return undefined;
  return numerator / denominator;
}

function percentChange(from: number, to: number): number { return from > 0 ? (to / from - 1) * 100 : 0; }
function min(a: bigint, b: bigint): bigint { return a < b ? a : b; }
