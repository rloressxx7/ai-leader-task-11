import type { Config } from "./config.js";
import { RiskManager, type ExitDecision } from "./risk-manager.js";
import type { Candidate, MarketSnapshot, PersistedPosition } from "./types.js";

export interface SignalAssessment {
  passes: boolean;
  buyRatio: number;
  netBuySol: number;
  score: number;
  desiredSizeSol: number;
}

export function assessSignal(config: Config, candidate: Candidate): SignalAssessment {
  const total = candidate.buys + candidate.sells;
  const buyRatio = total ? candidate.buys / total : 0;
  const netBuySol = candidate.buySol - candidate.sellSol;
  const cap = candidate.launch.marketCapSol;
  const passes = candidate.buyers.size >= config.MIN_UNIQUE_BUYERS && buyRatio >= config.MIN_BUY_RATIO &&
    netBuySol >= config.MIN_NET_BUY_SOL && cap >= config.MIN_MARKET_CAP_SOL && cap <= config.MAX_MARKET_CAP_SOL;
  const buyerScore = Math.min(1, candidate.buyers.size / (config.MIN_UNIQUE_BUYERS * 3));
  const flowScore = Math.min(1, netBuySol / Math.max(config.MIN_NET_BUY_SOL * 4, 0.01));
  const ratioScore = Math.max(0, Math.min(1, (buyRatio - config.MIN_BUY_RATIO) / (1 - config.MIN_BUY_RATIO)));
  const score = buyerScore * 0.4 + flowScore * 0.4 + ratioScore * 0.2;
  const desiredSizeSol = config.BASE_BUY_SOL + score ** 2 * (config.MAX_BUY_SOL - config.BASE_BUY_SOL);
  return { passes, buyRatio, netBuySol, score, desiredSizeSol };
}

export function decideExit(config: Config, position: PersistedPosition, marketCapSol: number, now: number): ExitDecision {
  const entryPrice = position.entryPriceSol ?? position.entryMarketCapSol / 1_000_000_000;
  const priceSol = entryPrice * marketCapSol / position.entryMarketCapSol;
  const peakPrice = Math.max(position.peakPriceSol ?? entryPrice * position.peakMarketCapSol / position.entryMarketCapSol, priceSol);
  const market: MarketSnapshot = {
    mint: position.mint, timestamp: now, priceSol, priceSource: "market-cap", marketCapSol,
    windowHighPriceSol: peakPrice, windowLowPriceSol: priceSol,
    windowChangePct: (priceSol / entryPrice - 1) * 100,
    windowDrawdownPct: (1 - priceSol / peakPrice) * 100,
    buyVolumeSol: 0, sellVolumeSol: 0, sellPressureRatio: 0, tradeCount: 1, stale: false
  };
  return new RiskManager(config).evaluate(position, market, now);
}

export type { ExitDecision };
