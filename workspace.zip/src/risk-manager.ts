import type { Config } from "./config.js";
import { capSellForImpact, estimatedSellImpactPct } from "./market-monitor.js";
import type { MarketSnapshot, PersistedPosition } from "./types.js";

export type ExitReason = "" | "liquidity-crisis" | "stop-loss" | "max-hold" | "flow-reversal" |
  "trailing-stop" | "take-profit-1" | "take-profit-2";

export interface ExitDecision {
  amount: bigint;
  desiredAmount: bigint;
  reason: ExitReason;
  pnlPct: number;
  drawdownPct: number;
  liquidityDrawdownPct?: number;
  estimatedPriceImpactPct?: number;
  marketStale: boolean;
}

/** Stateful exit policy. Position watermarks are updated before every decision and persisted by the engine. */
export class RiskManager {
  constructor(private readonly config: Config) {}

  evaluate(position: PersistedPosition, market: MarketSnapshot, now: number): ExitDecision {
    this.updateWatermarks(position, market);
    const remaining = BigInt(position.remainingTokenAmount);
    const initial = BigInt(position.initialTokenAmount);
    const entryPrice = position.entryPriceSol ?? position.entryMarketCapSol / 1_000_000_000;
    const peakPrice = position.peakPriceSol ?? entryPrice;
    const pnlPct = changePct(entryPrice, market.priceSol);
    const drawdownPct = peakPrice > 0 ? Math.max(0, (1 - market.priceSol / peakPrice) * 100) : 0;
    const liquidityDrawdownPct = position.peakLiquiditySol && market.liquiditySol !== undefined
      ? Math.max(0, (1 - market.liquiditySol / position.peakLiquiditySol) * 100)
      : undefined;
    const decide = (desiredAmount: bigint, reason: ExitReason): ExitDecision => {
      const amount = capSellForImpact(market, min(remaining, desiredAmount), position.tokenDecimals, this.config.MAX_EXIT_PRICE_IMPACT_PCT);
      const impact = estimatedSellImpactPct(market, amount, position.tokenDecimals);
      return {
        amount,
        desiredAmount: min(remaining, desiredAmount),
        reason,
        pnlPct,
        drawdownPct,
        ...(liquidityDrawdownPct !== undefined ? { liquidityDrawdownPct } : {}),
        ...(impact !== undefined ? { estimatedPriceImpactPct: impact } : {}),
        marketStale: market.stale
      };
    };
    const none = (): ExitDecision => decide(0n, "");

    if (remaining <= 0n) return none();
    // A partial fill must wait for a newer reserve observation before sizing its next slice.
    if (position.lastExitMarketTimestamp !== undefined && market.timestamp <= position.lastExitMarketTimestamp &&
      (position.lastExitAt === undefined || now - position.lastExitAt < this.config.MARKET_STALE_MS)) return none();
    if (!market.stale && market.liquiditySol !== undefined &&
      (market.liquiditySol <= this.config.MIN_EXIT_LIQUIDITY_SOL ||
       (liquidityDrawdownPct ?? 0) >= this.config.LIQUIDITY_DRAWDOWN_EXIT_PCT)) {
      return decide(remaining, "liquidity-crisis");
    }
    if (!market.stale && pnlPct <= -this.config.STOP_LOSS_PCT + 1e-9) return decide(remaining, "stop-loss");
    if (now - position.openedAt >= this.config.MAX_HOLD_MS) return decide(remaining, "max-hold");
    const rollingVolume = market.buyVolumeSol + market.sellVolumeSol;
    if (!market.stale && rollingVolume >= this.config.SELL_PRESSURE_MIN_VOLUME_SOL &&
      market.sellPressureRatio >= this.config.SELL_PRESSURE_EXIT_RATIO &&
      market.windowDrawdownPct >= this.config.SELL_PRESSURE_PRICE_DROP_PCT) {
      return decide(remaining, "flow-reversal");
    }
    if (!market.stale && position.firstTakeProfitDone && reached(drawdownPct, this.config.TRAILING_STOP_PCT)) {
      return decide(remaining, "trailing-stop");
    }
    if (!market.stale && !position.firstTakeProfitDone && reached(pnlPct, this.config.TAKE_PROFIT_1_PCT)) {
      return decide(outstandingStage(initial, position.firstTakeProfitSoldAmount, 35), "take-profit-1");
    }
    if (!market.stale && position.firstTakeProfitDone && !position.secondTakeProfitDone && reached(pnlPct, this.config.TAKE_PROFIT_2_PCT)) {
      return decide(outstandingStage(initial, position.secondTakeProfitSoldAmount, 35), "take-profit-2");
    }
    return none();
  }

  recordFill(position: PersistedPosition, reason: ExitReason, sold: bigint): void {
    if (reason !== "take-profit-1" && reason !== "take-profit-2") return;
    const initial = BigInt(position.initialTokenAmount);
    const target = percent(initial, 35);
    const key = reason === "take-profit-1" ? "firstTakeProfitSoldAmount" : "secondTakeProfitSoldAmount";
    const doneKey = reason === "take-profit-1" ? "firstTakeProfitDone" : "secondTakeProfitDone";
    const filled = BigInt(position[key] ?? "0") + sold;
    position[key] = filled.toString();
    position[doneKey] = filled >= target || BigInt(position.remainingTokenAmount) === 0n;
  }

  private updateWatermarks(position: PersistedPosition, market: MarketSnapshot): void {
    const entryPrice = position.entryPriceSol ?? position.entryMarketCapSol / 1_000_000_000;
    position.entryPriceSol = entryPrice;
    const priorPeakPrice = position.peakPriceSol ?? position.peakMarketCapSol / 1_000_000_000;
    position.peakPriceSol = Math.max(priorPeakPrice, market.priceSol);
    position.lastPriceSol = market.priceSol;
    position.peakMarketCapSol = Math.max(position.peakMarketCapSol, market.marketCapSol);
    position.lastMarketUpdateAt = market.timestamp;
    if (market.liquiditySol !== undefined) {
      position.entryLiquiditySol ??= market.liquiditySol;
      position.peakLiquiditySol = Math.max(position.peakLiquiditySol ?? 0, market.liquiditySol);
      position.lastLiquiditySol = market.liquiditySol;
    }
  }
}

function outstandingStage(initial: bigint, soldValue: string | undefined, pct: number): bigint {
  const target = percent(initial, pct);
  const sold = BigInt(soldValue ?? "0");
  return sold >= target ? 0n : target - sold;
}

function percent(value: bigint, pct: number): bigint { return value * BigInt(pct) / 100n; }
function min(a: bigint, b: bigint): bigint { return a < b ? a : b; }
function changePct(from: number, to: number): number { return from > 0 ? (to / from - 1) * 100 : 0; }
function reached(value: number, threshold: number): boolean { return value >= threshold - 1e-9; }
