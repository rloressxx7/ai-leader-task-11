import { setTimeout as delay } from "node:timers/promises";
import { log } from "./log.js";

interface RpcEnvelope<T> { jsonrpc: "2.0"; id: number; result?: T; error?: { code: number; message: string; data?: unknown } }
interface Endpoint {
  url: string;
  failures: number;
  blockedUntil: number;
  nextRequestAt: number;
  inflight: number;
  schedule: Promise<void>;
}

export interface TokenBalance { amount: bigint; decimals: number }

export class RpcPool {
  private readonly endpoints: Endpoint[];
  private cursor = 0;
  private requestId = 0;

  constructor(urls: string[], private readonly rps: number, private readonly timeoutMs: number) {
    if (urls.length === 0) throw new Error("At least one RPC_HTTP_URLS endpoint is required");
    this.endpoints = urls.map((url) => ({ url, failures: 0, blockedUntil: 0, nextRequestAt: 0, inflight: 0, schedule: Promise.resolve() }));
  }

  async request<T>(method: string, params: unknown[] = []): Promise<T> {
    let lastError: unknown;
    const attempts = Math.max(3, this.endpoints.length * 2);
    for (let attempt = 0; attempt < attempts; attempt++) {
      const endpoint = this.pick();
      try {
        return await this.call<T>(endpoint, method, params);
      } catch (error) {
        lastError = error;
        endpoint.failures++;
        const rateLimited = error instanceof RpcHttpError && error.status === 429;
        const backoff = rateLimited ? error.retryAfterMs : Math.min(30_000, 250 * 2 ** endpoint.failures);
        endpoint.blockedUntil = Date.now() + backoff + Math.floor(Math.random() * 150);
        log.warn({ method, endpoint: this.label(endpoint.url), attempt: attempt + 1, backoff, err: String(error) }, "RPC request failed; rotating endpoint");
      }
    }
    throw new Error(`All RPC endpoints failed for ${method}`, { cause: lastError });
  }

  async sendRawTransaction(bytes: Uint8Array): Promise<string> {
    const encoded = Buffer.from(bytes).toString("base64");
    const params = [encoded, { encoding: "base64", skipPreflight: false, preflightCommitment: "confirmed", maxRetries: 0 }];
    const results = await Promise.allSettled(this.endpoints.map((endpoint) => this.call<string>(endpoint, "sendTransaction", params)));
    const signatures = results.filter((r): r is PromiseFulfilledResult<string> => r.status === "fulfilled").map((r) => r.value);
    if (signatures.length === 0) {
      const errors = results.filter((r): r is PromiseRejectedResult => r.status === "rejected").map((r) => String(r.reason));
      throw new Error(`Transaction rejected by every RPC: ${errors.join(" | ")}`);
    }
    if (new Set(signatures).size !== 1) log.warn({ signatures }, "RPC providers returned differing signatures");
    return signatures[0]!;
  }

  async confirm(signature: string, timeoutMs = 45_000): Promise<void> {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const result = await this.request<{ value: Array<{ confirmationStatus?: string; err: unknown } | null> }>(
        "getSignatureStatuses", [[signature], { searchTransactionHistory: true }]
      );
      const status = result.value[0];
      if (status?.err) throw new Error(`Transaction ${signature} failed: ${JSON.stringify(status.err)}`);
      if (status?.confirmationStatus === "confirmed" || status?.confirmationStatus === "finalized") return;
      await delay(800);
    }
    throw new Error(`Timed out confirming ${signature}; inspect it before retrying`);
  }

  async getBalance(owner: string): Promise<number> {
    const result = await this.request<{ value: number }>("getBalance", [owner, { commitment: "confirmed" }]);
    return result.value / 1_000_000_000;
  }

  async getTokenBalance(owner: string, mint: string): Promise<TokenBalance> {
    const result = await this.request<{ value: Array<{ account: { data: { parsed: { info: { mint: string; tokenAmount: { amount: string; decimals: number } } } } } }> }>(
      "getTokenAccountsByOwner", [owner, { mint }, { encoding: "jsonParsed", commitment: "confirmed" }]
    );
    let amount = 0n;
    let decimals = 6;
    for (const item of result.value) {
      amount += BigInt(item.account.data.parsed.info.tokenAmount.amount);
      decimals = item.account.data.parsed.info.tokenAmount.decimals;
    }
    return { amount, decimals };
  }

  async validateMint(mint: string): Promise<{ safe: boolean; reason?: string; decimals?: number }> {
    const result = await this.request<{ value: { data: { parsed?: { info?: Record<string, unknown> } } } | null }>(
      "getAccountInfo", [mint, { encoding: "jsonParsed", commitment: "confirmed" }]
    );
    const info = result.value?.data.parsed?.info;
    if (!info) return { safe: false, reason: "mint account unavailable or unparsable" };
    if (info.freezeAuthority) return { safe: false, reason: "freeze authority is active" };
    if (info.mintAuthority) return { safe: false, reason: "mint authority is active" };
    const decimals = Number(info.decimals);
    if (!Number.isInteger(decimals) || decimals < 0 || decimals > 9) return { safe: false, reason: "unexpected mint decimals" };
    return { safe: true, decimals };
  }

  private pick(): Endpoint {
    const now = Date.now();
    const available = this.endpoints.filter((e) => e.blockedUntil <= now).sort((a, b) => a.inflight - b.inflight);
    if (available.length > 0) return available[this.cursor++ % available.length]!;
    return [...this.endpoints].sort((a, b) => a.blockedUntil - b.blockedUntil)[0]!;
  }

  private async call<T>(endpoint: Endpoint, method: string, params: unknown[]): Promise<T> {
    const scheduled = endpoint.schedule.then(async () => {
      const waitMs = Math.max(0, endpoint.blockedUntil - Date.now(), endpoint.nextRequestAt - Date.now());
      if (waitMs) await delay(waitMs);
      endpoint.nextRequestAt = Date.now() + Math.ceil(1_000 / this.rps);
    });
    endpoint.schedule = scheduled.catch(() => undefined);
    await scheduled;
    endpoint.inflight++;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await fetch(endpoint.url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ jsonrpc: "2.0", id: ++this.requestId, method, params }),
        signal: controller.signal
      });
      if (!response.ok) {
        throw new RpcHttpError(response.status, retryAfter(response.headers.get("retry-after")));
      }
      const body = await response.json() as RpcEnvelope<T>;
      if (body.error) throw new Error(`RPC ${body.error.code}: ${body.error.message}`);
      endpoint.failures = 0;
      endpoint.blockedUntil = 0;
      return body.result as T;
    } finally {
      clearTimeout(timeout);
      endpoint.inflight--;
    }
  }

  private label(url: string): string {
    try { return new URL(url).host; } catch { return "invalid-url"; }
  }
}

class RpcHttpError extends Error {
  constructor(readonly status: number, readonly retryAfterMs: number) { super(`HTTP ${status}`); }
}

function retryAfter(value: string | null): number {
  if (!value) return 1_000;
  const seconds = Number(value);
  if (Number.isFinite(seconds)) return Math.max(0, seconds * 1_000);
  const date = Date.parse(value);
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : 1_000;
}
