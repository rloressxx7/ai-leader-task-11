import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import type { EngineState } from "./types.js";

export class StateStore {
  private writes: Promise<void> = Promise.resolve();
  constructor(private readonly filename: string) {}

  async load(): Promise<EngineState> {
    try {
      const value = JSON.parse(await readFile(this.filename, "utf8")) as Partial<EngineState>;
      if (!Array.isArray(value.positions) || typeof value.date !== "string" || typeof value.spentTodaySol !== "number") throw new Error("invalid state shape");
      return value as EngineState;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw new Error(`Unable to load ${this.filename}`, { cause: error });
      return { date: utcDate(), spentTodaySol: 0, positions: [] };
    }
  }

  async save(state: EngineState): Promise<void> {
    const payload = `${JSON.stringify(state, null, 2)}\n`;
    const write = this.writes.then(async () => {
      await mkdir(path.dirname(path.resolve(this.filename)), { recursive: true });
      const temporary = `${this.filename}.${process.pid}.tmp`;
      await writeFile(temporary, payload, { encoding: "utf8", mode: 0o600 });
      await rename(temporary, this.filename);
    });
    this.writes = write.catch(() => undefined);
    await write;
  }
}

export function utcDate(now = new Date()): string { return now.toISOString().slice(0, 10); }
