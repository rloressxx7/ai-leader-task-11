import { existsSync } from "node:fs";
import type { Config } from "./config.js";
import { PumpPortalFeed } from "./feed.js";
import { log } from "./log.js";
import { MarketMonitor } from "./market-monitor.js";
import { RpcPool } from "./rpc-pool.js";
import { assessSignal } from "./policy.js";
import { RiskManager } from "./risk-manager.js";
import { StateStore, utcDate } from "./state-store.js";
import type { Candidate, EngineState, LaunchEvent, MarketSnapshot, PersistedPosition, TradeEvent, TradeExecutor } from "./types.js";

export class MomentumEngine {
  private state!: EngineState;
  private readonly candidates = new Map<string, Candidate>();
  private readonly exiting = new Set<string>();
  private readonly staleMarkets = new Set<string>();
  private readonly timers = new Set<NodeJS.Timeout>();
  private reservedEntries = 0;
  private reservedSpend = 0;
  private readonly pending = new Set<Promise<unknown>>();
  private maintenance?: NodeJS.Timeout;
  private readonly monitor: MarketMonitor;
  private readonly risk: RiskManager;
  private marketStateDirty = false;
  private lastRiskCheckpointAt = 0;

  constructor(
    private readonly config: Config,
    private readonly feed: PumpPortalFeed,
    private readonly executor: TradeExecutor,
    private readonly store: StateStore,
    private readonly rpc?: RpcPool,
    private readonly wallet?: string
  ) {
    this.monitor = new MarketMonitor(config);
    this.risk = new RiskManager(config);
  }

  async start(): Promise<void> {
    this.state = await this.store.load();
    for (const position of this.state.positions) {
      position.tokenDecimals ??= 6;
      position.entryPriceSol ??= position.entryMarketCapSol / 1_000_000_000;
      position.peakPriceSol ??= position.peakMarketCapSol / 1_000_000_000;
      position.lastPriceSol ??= position.entryPriceSol;
      position.firstTakeProfitSoldAmount ??= position.firstTakeProfitDone ? percent(BigInt(position.initialTokenAmount), 35).toString() : "0";
      position.secondTakeProfitSoldAmount ??= position.secondTakeProfitDone ? percent(BigInt(position.initialTokenAmount), 35).toString() : "0";
      this.monitor.seed(position);
    }
    this.resetDailyBudget();
    for (const position of this.state.positions) this.feed.watch(position.mint);
    this.feed.on("launch", (event) => this.onLaunch(event));
    this.feed.on("trade", (event) => { this.track(this.onTrade(event)); });
    this.feed.on("error", (error) => log.error({ err: error }, "Market stream error"));
    this.maintenance = setInterval(() => { this.track(this.runMaintenance()); }, 1_000);
    this.feed.start();
    log.info({ dryRun: this.config.DRY_RUN, recoveredPositions: this.state.positions.length, spentTodaySol: this.state.spentTodaySol }, "Momentum engine started");
  }

  async stop(): Promise<void> {
    this.feed.stop();
    if (this.maintenance) clearInterval(this.maintenance);
    for (const timer of this.timers) clearTimeout(timer);
    await Promise.allSettled([...this.pending]);
    await this.store.save(this.state);
  }

  private onLaunch(event: LaunchEvent): void {
    if (this.candidates.has(event.mint) || this.position(event.mint)) return;
    if (this.candidates.size >= this.config.MAX_TRACKED_CANDIDATES) return;
    const rejection = this.launchRejection(event);
    if (rejection) { log.debug({ mint: event.mint, reason: rejection }, "Launch rejected"); return; }
    this.monitor.observe(event);
    const candidate: Candidate = {
      launch: event, buys: event.solAmount > 0 ? 1 : 0, sells: 0,
      buySol: event.solAmount, sellSol: 0, buyers: new Set(event.trader ? [event.trader] : []), evaluated: false
    };
    this.candidates.set(event.mint, candidate);
    this.feed.watch(event.mint);
    const timer = setTimeout(() => {
      this.timers.delete(timer);
      this.track(this.evaluate(candidate));
    }, this.config.OBSERVATION_MS);
    this.timers.add(timer);
  }

  private async onTrade(event: TradeEvent): Promise<void> {
    const market = this.monitor.observe(event);
    if (!market) return;
    const candidate = this.candidates.get(event.mint);
    if (candidate && !candidate.evaluated) {
      candidate.launch.marketCapSol = event.marketCapSol || candidate.launch.marketCapSol;
      if (event.side === "buy") {
        candidate.buys++;
        candidate.buySol += event.solAmount;
        if (event.trader) candidate.buyers.add(event.trader);
      } else {
        candidate.sells++;
        candidate.sellSol += event.solAmount;
      }
    }
    const position = this.position(event.mint);
    if (position && market) {
      if (event.pool === "pump-amm") position.pool = "pump-amm";
      this.marketStateDirty = true;
      await this.manage(position, market, event.timestamp);
    }
  }

  private async evaluate(candidate: Candidate): Promise<void> {
    if (candidate.evaluated) return;
    candidate.evaluated = true;
    const assessment = assessSignal(this.config, candidate);
    const ratio = assessment.buyRatio;
    const netSol = assessment.netBuySol;
    const cap = candidate.launch.marketCapSol;
    if (!assessment.passes) {
      log.info({ mint: candidate.launch.mint, buyers: candidate.buyers.size, ratio, netSol, marketCapSol: cap }, "Candidate rejected after observation");
      this.discard(candidate.launch.mint);
      return;
    }
    if (!this.canEnter()) { this.discard(candidate.launch.mint); return; }

    const score = assessment.score;
    const desired = assessment.desiredSizeSol;
    const remainingBudget = this.config.MAX_DAILY_SPEND_SOL - this.state.spentTodaySol - this.reservedSpend;
    const size = Math.min(desired, this.config.MAX_BUY_SOL, remainingBudget);
    if (size < this.config.BASE_BUY_SOL) { this.discard(candidate.launch.mint); return; }

    this.reservedEntries++;
    this.reservedSpend += size;
    try {
      if (this.rpc) {
        const validation = await this.rpc.validateMint(candidate.launch.mint);
        if (!validation.safe) throw new Error(`Unsafe mint: ${validation.reason}`);
      }
      if (this.rpc && this.wallet) {
        const balance = await this.rpc.getBalance(this.wallet);
        if (balance - size - this.config.PRIORITY_FEE_SOL < this.config.MIN_WALLET_RESERVE_SOL) throw new Error("Wallet reserve guard triggered");
      }
      const market = this.monitor.snapshot(candidate.launch.mint);
      if (!market || market.stale) throw new Error("Market data became stale before entry");
      if (market.liquiditySol === undefined) throw new Error("Executable liquidity data is unavailable");
      if (market.liquiditySol < this.config.MIN_ENTRY_LIQUIDITY_SOL) {
        throw new Error(`Insufficient executable liquidity: ${market.liquiditySol.toFixed(3)} SOL`);
      }
      const result = await this.executor.buy(candidate.launch.mint, size, candidate.launch.pool);
      const decimals = result.tokenDecimals ?? 6;
      const simulated = BigInt(Math.max(1, Math.floor((size / cap) * 1_000_000_000 * 10 ** decimals)));
      const amount = result.tokenAmount ?? simulated;
      const observedPrice = market?.priceSol ?? cap / 1_000_000_000;
      const entryPrice = executionPrice(size, amount, decimals, observedPrice);
      this.state.positions.push({
        mint: candidate.launch.mint, symbol: candidate.launch.symbol, pool: candidate.launch.pool,
        openedAt: Date.now(), entryMarketCapSol: cap, peakMarketCapSol: cap, spentSol: size,
        entryPriceSol: entryPrice, peakPriceSol: Math.max(entryPrice, observedPrice), lastPriceSol: observedPrice,
        ...(market?.liquiditySol !== undefined ? {
          entryLiquiditySol: market.liquiditySol,
          peakLiquiditySol: market.liquiditySol,
          lastLiquiditySol: market.liquiditySol
        } : {}),
        ...(market ? { lastMarketUpdateAt: market.timestamp } : {}),
        initialTokenAmount: amount.toString(), remainingTokenAmount: amount.toString(), tokenDecimals: decimals,
        firstTakeProfitDone: false, secondTakeProfitDone: false,
        firstTakeProfitSoldAmount: "0", secondTakeProfitSoldAmount: "0", entrySignature: result.signature
      });
      this.state.spentTodaySol += size;
      await this.store.save(this.state);
      log.info({ mint: candidate.launch.mint, size, score, signature: result.signature }, "Position opened");
    } catch (error) {
      log.error({ mint: candidate.launch.mint, err: String(error) }, "Entry failed");
      this.discard(candidate.launch.mint);
    } finally {
      this.reservedEntries--;
      this.reservedSpend -= size;
      this.candidates.delete(candidate.launch.mint);
    }
  }

  private async manage(position: PersistedPosition, market: MarketSnapshot, now: number): Promise<void> {
    if (this.exiting.has(position.mint)) return;
    const decision = this.risk.evaluate(position, market, now);
    const { amount, reason, pnlPct } = decision;
    const remaining = BigInt(position.remainingTokenAmount);
    if (amount <= 0n) return;
    this.exiting.add(position.mint);
    try {
      const result = await this.executor.sell(position.mint, amount, position.tokenDecimals, position.pool);
      const sold = minBigInt(remaining, result.tokenAmount ?? amount);
      position.remainingTokenAmount = (remaining - sold).toString();
      position.lastExitMarketTimestamp = market.timestamp;
      position.lastExitAt = Date.now();
      this.risk.recordFill(position, reason, sold);
      if (BigInt(position.remainingTokenAmount) === 0n) {
        this.state.positions = this.state.positions.filter((p) => p.mint !== position.mint);
        this.feed.unwatch(position.mint);
        this.monitor.forget(position.mint);
        this.staleMarkets.delete(position.mint);
      }
      await this.store.save(this.state);
      this.marketStateDirty = false;
      this.lastRiskCheckpointAt = Date.now();
      log.info({
        mint: position.mint, reason, pnlPct, drawdownPct: decision.drawdownPct,
        liquiditySol: market.liquiditySol, liquidityDrawdownPct: decision.liquidityDrawdownPct,
        sellPressureRatio: market.sellPressureRatio, estimatedPriceImpactPct: decision.estimatedPriceImpactPct,
        sold: sold.toString(), desired: decision.desiredAmount.toString(), signature: result.signature
      }, "Position reduced");
    } catch (error) {
      log.error({ mint: position.mint, reason, err: String(error) }, "Exit failed; position retained for retry");
    } finally { this.exiting.delete(position.mint); }
  }

  private async runMaintenance(): Promise<void> {
    this.resetDailyBudget();
    const now = Date.now();
    for (const position of [...this.state.positions]) {
      const market = this.monitor.snapshot(position.mint, now);
      if (!market) continue;
      if (market.stale && !this.staleMarkets.has(position.mint)) {
        this.staleMarkets.add(position.mint);
        log.warn({ mint: position.mint, ageMs: now - market.timestamp }, "Position market data is stale; price-based exits paused");
      } else if (!market.stale && this.staleMarkets.delete(position.mint)) {
        log.info({ mint: position.mint }, "Position market data recovered");
      }
      await this.manage(position, market, now);
    }
    if (this.marketStateDirty && now - this.lastRiskCheckpointAt >= this.config.RISK_CHECKPOINT_MS) {
      await this.store.save(this.state);
      this.marketStateDirty = false;
      this.lastRiskCheckpointAt = now;
    }
  }

  private canEnter(): boolean {
    if (existsSync(this.config.HALT_FILE)) { log.warn("HALT file present; new entries disabled"); return false; }
    if (this.state.positions.length + this.reservedEntries >= this.config.MAX_OPEN_POSITIONS) return false;
    if (this.state.spentTodaySol + this.reservedSpend + this.config.BASE_BUY_SOL > this.config.MAX_DAILY_SPEND_SOL) return false;
    return true;
  }

  private launchRejection(event: LaunchEvent): string | undefined {
    if (!event.mint || !event.trader) return "missing identifiers";
    if (event.pool !== "pump") return "not a Pump bonding-curve launch";
    if (event.marketCapSol <= 0 || event.marketCapSol > this.config.MAX_MARKET_CAP_SOL) return "market cap outside launch range";
    const creatorPct = event.tokenAmount > 0 ? event.tokenAmount / 1_000_000_000 * 100 : 0;
    if (creatorPct > this.config.MAX_CREATOR_INITIAL_BUY_PCT) return "creator initial allocation too large";
    if (/test|scam|rug/i.test(`${event.name} ${event.symbol}`)) return "blocked metadata keyword";
    return undefined;
  }

  private discard(mint: string): void {
    this.candidates.delete(mint);
    if (!this.position(mint)) { this.feed.unwatch(mint); this.monitor.forget(mint); }
  }
  private position(mint: string): PersistedPosition | undefined { return this.state.positions.find((p) => p.mint === mint); }
  private resetDailyBudget(): void {
    const today = utcDate();
    if (this.state.date !== today) { this.state.date = today; this.state.spentTodaySol = 0; void this.store.save(this.state); }
  }

  private track(promise: Promise<unknown>): void {
    this.pending.add(promise);
    void promise.then(() => this.pending.delete(promise), () => this.pending.delete(promise));
  }
}

function minBigInt(a: bigint, b: bigint): bigint { return a < b ? a : b; }
function percent(value: bigint, pct: number): bigint { return value * BigInt(pct) / 100n; }
function executionPrice(spentSol: number, rawTokens: bigint, decimals: number, fallback: number): number {
  const tokens = Number(rawTokens) / 10 ** decimals;
  const price = spentSol / tokens;
  return Number.isFinite(price) && price > 0 ? price : fallback;
}
