export type Side = "buy" | "sell";

export interface LaunchEvent {
  kind: "launch";
  signature: string;
  mint: string;
  trader: string;
  name: string;
  symbol: string;
  uri?: string;
  solAmount: number;
  tokenAmount: number;
  marketCapSol: number;
  pool: string;
  timestamp: number;
  virtualSolReserves?: number;
  virtualTokenReserves?: number;
  realSolReserves?: number;
  realTokenReserves?: number;
}

export interface TradeEvent {
  kind: "trade";
  signature: string;
  mint: string;
  trader: string;
  side: Side;
  solAmount: number;
  tokenAmount: number;
  marketCapSol: number;
  pool: string;
  timestamp: number;
  virtualSolReserves?: number;
  virtualTokenReserves?: number;
  realSolReserves?: number;
  realTokenReserves?: number;
}

export interface Candidate {
  launch: LaunchEvent;
  buys: number;
  sells: number;
  buySol: number;
  sellSol: number;
  buyers: Set<string>;
  evaluated: boolean;
}

export interface PersistedPosition {
  mint: string;
  symbol: string;
  pool: string;
  openedAt: number;
  entryMarketCapSol: number;
  peakMarketCapSol: number;
  entryPriceSol?: number;
  peakPriceSol?: number;
  lastPriceSol?: number;
  entryLiquiditySol?: number;
  peakLiquiditySol?: number;
  lastLiquiditySol?: number;
  lastMarketUpdateAt?: number;
  lastExitMarketTimestamp?: number;
  lastExitAt?: number;
  spentSol: number;
  initialTokenAmount: string;
  remainingTokenAmount: string;
  tokenDecimals: number;
  firstTakeProfitDone: boolean;
  secondTakeProfitDone: boolean;
  firstTakeProfitSoldAmount?: string;
  secondTakeProfitSoldAmount?: string;
  entrySignature: string;
}

export type MarketPriceSource = "bonding-curve" | "market-cap";

export interface MarketSnapshot {
  mint: string;
  timestamp: number;
  priceSol: number;
  priceSource: MarketPriceSource;
  marketCapSol: number;
  windowHighPriceSol: number;
  windowLowPriceSol: number;
  windowChangePct: number;
  windowDrawdownPct: number;
  buyVolumeSol: number;
  sellVolumeSol: number;
  sellPressureRatio: number;
  tradeCount: number;
  liquiditySol?: number;
  peakLiquiditySol?: number;
  liquidityDrawdownPct?: number;
  virtualTokenReserves?: number;
  stale: boolean;
}

export interface EngineState {
  date: string;
  spentTodaySol: number;
  positions: PersistedPosition[];
}

export interface ExecutionResult {
  signature: string;
  tokenAmount?: bigint;
  tokenDecimals?: number;
}

export interface TradeExecutor {
  buy(mint: string, solAmount: number, pool: string): Promise<ExecutionResult>;
  sell(mint: string, tokenAmount: bigint, tokenDecimals: number, pool: string): Promise<ExecutionResult>;
}
