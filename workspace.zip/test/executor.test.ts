import { describe, expect, it } from "vitest";
import { decimalUnits } from "../src/executor.js";

describe("decimalUnits", () => {
  it("converts raw token units without floating-point loss", () => {
    expect(decimalUnits(123456789012345n, 6)).toBe("123456789.012345");
    expect(decimalUnits(1000000n, 6)).toBe("1");
    expect(decimalUnits(1n, 6)).toBe("0.000001");
    expect(decimalUnits(42n, 0)).toBe("42");
  });
});
