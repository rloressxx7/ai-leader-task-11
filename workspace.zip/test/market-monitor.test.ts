import { describe, expect, it } from "vitest";
import { config } from "../src/config.js";
import { capSellForImpact, estimatedSellImpactPct, MarketMonitor } from "../src/market-monitor.js";
import type { MarketSnapshot, TradeEvent } from "../src/types.js";

function trade(overrides: Partial<TradeEvent> = {}): TradeEvent {
  return {
    kind: "trade", signature: "sig-1", mint: "mint", trader: "wallet", side: "buy",
    solAmount: 1, tokenAmount: 10, marketCapSol: 40, pool: "pump", timestamp: 1_000,
    virtualSolReserves: 34, virtualTokenReserves: 800_000_000, ...overrides
  };
}

describe("MarketMonitor", () => {
  it("tracks reserve price, executable liquidity, rolling flow, and duplicate signatures", () => {
    const monitor = new MarketMonitor({ ...config, MARKET_WINDOW_MS: 30_000, MARKET_STALE_MS: 5_000 });
    const first = monitor.observe(trade())!;
    expect(first.priceSource).toBe("bonding-curve");
    expect(first.priceSol).toBeCloseTo(34 / 800_000_000);
    expect(first.liquiditySol).toBe(4);

    const secondEvent = trade({ signature: "sig-2", side: "sell", solAmount: 2, timestamp: 2_000,
      virtualSolReserves: 33, virtualTokenReserves: 825_000_000, marketCapSol: 39 });
    const second = monitor.observe(secondEvent)!;
    expect(second.tradeCount).toBe(2);
    expect(second.sellPressureRatio).toBeCloseTo(2 / 3);
    expect(second.liquidityDrawdownPct).toBe(25);
    expect(second.windowDrawdownPct).toBeGreaterThan(0);

    expect(monitor.observe(secondEvent)).toBeUndefined();
    expect(monitor.snapshot("mint", 8_000)!.stale).toBe(true);
  });

  it("falls back to supply-normalized market cap when reserve data is absent", () => {
    const monitor = new MarketMonitor(config);
    const event = trade({ marketCapSol: 55 });
    delete event.virtualSolReserves;
    delete event.virtualTokenReserves;
    const snapshot = monitor.observe(event)!;
    expect(snapshot.priceSource).toBe("market-cap");
    expect(snapshot.priceSol).toBe(55 / 1_000_000_000);
    expect(snapshot.liquiditySol).toBeUndefined();
  });

  it("caps a curve sale to its configured price impact", () => {
    const snapshot = { virtualTokenReserves: 1_000 } as MarketSnapshot;
    const capped = capSellForImpact(snapshot, 500n, 0, 5);
    expect(capped).toBe(52n);
    expect(estimatedSellImpactPct(snapshot, capped, 0)).toBeLessThanOrEqual(5);
  });
});
