import { describe, expect, it } from "vitest";
import { config } from "../src/config.js";
import { assessSignal, decideExit } from "../src/policy.js";
import type { Candidate, PersistedPosition } from "../src/types.js";

const launch = { kind: "launch" as const, signature: "sig", mint: "mint", trader: "creator", name: "Token", symbol: "T",
  solAmount: 0.1, tokenAmount: 1, marketCapSol: 40, pool: "pump", timestamp: 0 };

describe("momentum policy", () => {
  it("requires broad net buying and scales strong signals", () => {
    const weak: Candidate = { launch: { ...launch }, buys: 3, sells: 2, buySol: 0.4, sellSol: 0.2,
      buyers: new Set(["a", "b", "c"]), evaluated: false };
    expect(assessSignal(config, weak).passes).toBe(false);
    const strong: Candidate = { ...weak, buys: 12, sells: 1, buySol: 3, sellSol: 0.1,
      buyers: new Set(["a", "b", "c", "d", "e", "f", "g", "h"]) };
    const result = assessSignal(config, strong);
    expect(result.passes).toBe(true);
    expect(result.desiredSizeSol).toBeGreaterThan(config.BASE_BUY_SOL);
    expect(result.desiredSizeSol).toBeLessThanOrEqual(config.MAX_BUY_SOL);
  });

  it("sells exact original-position tranches and protects the remainder", () => {
    const position: PersistedPosition = { mint: "mint", symbol: "T", pool: "pump", openedAt: 0,
      entryMarketCapSol: 100, peakMarketCapSol: 100, spentSol: 1, initialTokenAmount: "1000",
      remainingTokenAmount: "1000", tokenDecimals: 6, firstTakeProfitDone: false,
      secondTakeProfitDone: false, entrySignature: "sig" };
    expect(decideExit(config, position, 125, 1).amount).toBe(350n);
    position.firstTakeProfitDone = true;
    position.remainingTokenAmount = "650";
    position.peakMarketCapSol = 165;
    expect(decideExit(config, position, 165, 2)).toMatchObject({ amount: 350n, reason: "take-profit-2" });
    position.secondTakeProfitDone = true;
    position.remainingTokenAmount = "300";
    expect(decideExit(config, position, 120, 3)).toMatchObject({ amount: 300n, reason: "trailing-stop" });
  });
});
