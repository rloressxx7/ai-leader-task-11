import { describe, expect, it } from "vitest";
import { config } from "../src/config.js";
import { RiskManager } from "../src/risk-manager.js";
import type { MarketSnapshot, PersistedPosition } from "../src/types.js";

function position(overrides: Partial<PersistedPosition> = {}): PersistedPosition {
  return {
    mint: "mint", symbol: "T", pool: "pump", openedAt: 0,
    entryMarketCapSol: 100, peakMarketCapSol: 100, entryPriceSol: 1, peakPriceSol: 1,
    lastPriceSol: 1, spentSol: 1, initialTokenAmount: "1000", remainingTokenAmount: "1000",
    tokenDecimals: 0, firstTakeProfitDone: false, secondTakeProfitDone: false,
    firstTakeProfitSoldAmount: "0", secondTakeProfitSoldAmount: "0", entrySignature: "sig", ...overrides
  };
}

function market(overrides: Partial<MarketSnapshot> = {}): MarketSnapshot {
  return {
    mint: "mint", timestamp: 1_000, priceSol: 1, priceSource: "bonding-curve", marketCapSol: 100,
    windowHighPriceSol: 1, windowLowPriceSol: 1, windowChangePct: 0, windowDrawdownPct: 0,
    buyVolumeSol: 1, sellVolumeSol: 0, sellPressureRatio: 0, tradeCount: 4, stale: false, ...overrides
  };
}

describe("RiskManager", () => {
  it("exits the remainder on stop loss and max hold", () => {
    const risk = new RiskManager(config);
    expect(risk.evaluate(position(), market({ priceSol: 0.8, marketCapSol: 80 }), 1_000)).toMatchObject({
      amount: 1000n, reason: "stop-loss"
    });
    expect(risk.evaluate(position(), market({ stale: true }), config.MAX_HOLD_MS)).toMatchObject({
      amount: 1000n, reason: "max-hold", marketStale: true
    });
  });

  it("takes two 35% tranches and trails the remainder", () => {
    const risk = new RiskManager(config);
    const held = position();
    const first = risk.evaluate(held, market({ priceSol: 1.25, marketCapSol: 125 }), 1_000);
    expect(first).toMatchObject({ amount: 350n, reason: "take-profit-1" });
    held.remainingTokenAmount = "650";
    risk.recordFill(held, first.reason, 350n);
    expect(held.firstTakeProfitDone).toBe(true);
    const second = risk.evaluate(held, market({ priceSol: 1.65, marketCapSol: 165 }), 2_000);
    expect(second).toMatchObject({ amount: 350n, reason: "take-profit-2" });
    held.remainingTokenAmount = "300";
    risk.recordFill(held, second.reason, 350n);
    expect(risk.evaluate(held, market({ priceSol: 1.2, marketCapSol: 120 }), 3_000)).toMatchObject({
      amount: 300n, reason: "trailing-stop"
    });
  });

  it("exits on disappearing depth or a high-volume sell reversal", () => {
    const risk = new RiskManager(config);
    const thin = position({ entryLiquiditySol: 5, peakLiquiditySol: 5, lastLiquiditySol: 5 });
    expect(risk.evaluate(thin, market({ liquiditySol: 0.5, peakLiquiditySol: 5 }), 1_000).reason).toBe("liquidity-crisis");

    const flow = market({ priceSol: 0.95, windowHighPriceSol: 1.1, windowDrawdownPct: 13.64,
      buyVolumeSol: 0.1, sellVolumeSol: 0.9, sellPressureRatio: 0.9 });
    expect(risk.evaluate(position(), flow, 1_000).reason).toBe("flow-reversal");
  });

  it("splits exits that would exceed the curve impact limit without completing the stage early", () => {
    const risk = new RiskManager({ ...config, MAX_EXIT_PRICE_IMPACT_PCT: 5 });
    const held = position();
    const decision = risk.evaluate(held, market({ priceSol: 1.3, marketCapSol: 130, virtualTokenReserves: 1_000 }), 1_000);
    expect(decision.reason).toBe("take-profit-1");
    expect(decision.amount).toBe(52n);
    held.remainingTokenAmount = "948";
    risk.recordFill(held, decision.reason, 52n);
    expect(held.firstTakeProfitDone).toBe(false);
    expect(held.firstTakeProfitSoldAmount).toBe("52");
  });

  it("waits for a fresh reserve update before sizing another partial exit", () => {
    const risk = new RiskManager(config);
    const held = position({ lastExitMarketTimestamp: 1_000, lastExitAt: 1_000 });
    expect(risk.evaluate(held, market({ timestamp: 1_000, priceSol: 0.5 }), 1_001).reason).toBe("");
    expect(risk.evaluate(held, market({ timestamp: 1_001, priceSol: 0.5 }), 1_002).reason).toBe("stop-loss");
  });
});
