import { afterEach, describe, expect, it, vi } from "vitest";
import { RpcPool } from "../src/rpc-pool.js";

afterEach(() => vi.unstubAllGlobals());

describe("RpcPool", () => {
  it("rotates away from a rate-limited endpoint", async () => {
    const calls: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (input: string | URL | Request) => {
      const url = String(input);
      calls.push(url);
      if (url.includes("primary")) return new Response("rate limited", { status: 429, headers: { "retry-after": "0" } });
      return new Response(JSON.stringify({ jsonrpc: "2.0", id: 2, result: { value: 42 } }), { status: 200 });
    }));
    const pool = new RpcPool(["https://primary.example", "https://backup.example"], 1_000, 1_000);
    await expect(pool.request("getBalance", ["wallet"])).resolves.toEqual({ value: 42 });
    expect(calls).toEqual(["https://primary.example", "https://backup.example"]);
  });
});
