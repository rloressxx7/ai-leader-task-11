import { mkdtemp, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { StateStore } from "../src/state-store.js";

describe("StateStore", () => {
  it("round-trips bigint-compatible persisted position fields", async () => {
    const dir = await mkdtemp(path.join(tmpdir(), "pump-engine-"));
    const filename = path.join(dir, "nested", "state.json");
    const store = new StateStore(filename);
    const state = {
      date: "2026-09-27", spentTodaySol: 0.5,
      positions: [{ mint: "mint", symbol: "T", pool: "pump", openedAt: 1, entryMarketCapSol: 20,
        peakMarketCapSol: 30, spentSol: 0.5, initialTokenAmount: "90071992547409930",
        remainingTokenAmount: "90071992547409930", tokenDecimals: 6, firstTakeProfitDone: false,
        secondTakeProfitDone: false, entrySignature: "sig" }]
    };
    await store.save(state);
    expect(await store.load()).toEqual(state);
    expect((await readFile(filename, "utf8")).endsWith("\n")).toBe(true);
  });

  it("serializes concurrent atomic writes", async () => {
    const dir = await mkdtemp(path.join(tmpdir(), "pump-engine-"));
    const store = new StateStore(path.join(dir, "state.json"));
    const first = { date: "2026-09-27", spentTodaySol: 1, positions: [] };
    const second = { date: "2026-09-27", spentTodaySol: 2, positions: [] };
    await Promise.all([store.save(first), store.save(second)]);
    expect(await store.load()).toEqual(second);
  });
});
